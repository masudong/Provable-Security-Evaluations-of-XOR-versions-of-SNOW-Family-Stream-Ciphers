import numpy as np
from scipy.stats import norm
import math


Success_rate = 0.99

def tao(p, FSR_A):

    L = 512 - FSR_A
    for canshu in range(1):
        sum = 0

        for i in range(canshu + 1):
            sum += 2 ** p[i]

        e = sum / (canshu + 1)
        print(math.log(e, 2))

        max1 = 512
        max_B = 0
        max_M = 0
        max_k = 0
        max_T1 = 0
        max_T2 = 0
        max_N = 0
        max_N2 = 0
        max_Memory = 0
        mmax_T = 0
        for k in range(2, 13):
            for B in range(1, L):
                c_K = e ** (2 * k)
                #M = ((norm.ppf(Success_rate) + (2 * (B + 1) * math.log(2, math.e)) ** (1 / 2)) ** 2) / c_K
                M = ((norm.ppf(Success_rate) - norm.ppf(2 ** (-B - 1))) ** 2) / c_K
                Mk = (M**(1/(1+int(math.log(k,2))))) * k * 2**((L-B)/(1+int(math.log(k,2))))

                if M > 2**((L-B)/int(math.log2(k))):
                    continue

                if k == 2:
                    T1 = Mk / 2
                else:
                    T1 = Mk

                if B > math.log(M, 2) and (M + B * (2 ** B)) > ((2 ** B) * (2 + int(math.log(M, 2)))):
                    T2 = ((2 ** B) * (2 + int(math.log(M, 2))))
                else:
                    T2 = (M + B * (2 ** B))

                Memory = max(Mk, 2 ** B)

                maxx_M = math.log(M, 2)

                maxx_N = math.log(Mk, 2)

                maxx_T = math.log(T2 + T1, 2)
                maxx_T1 = math.log(T1, 2)
                maxx_T2 = math.log(T2, 2)
                maxx_Memory = math.log(Memory, 2)
                maxx = max(maxx_Memory, maxx_T, maxx_N)

                if max1 > maxx:
                    max_k = k
                    max1 = maxx
                    max_M = maxx_M
                    max_N2 = maxx_N
                    max_N = math.log(Mk, 2)
                    max_Memory = maxx_Memory
                    max_T1 = maxx_T1
                    max_T2 = maxx_T2
                    max_B = B
                    mmax_T = maxx_T

        print("k:{}, B:{}, remaining bits:{}, attack complexity: 2^{}".format(max_k, max_B, L - max_B, max1))
        print("The parity check equations M: 2^{},".format(max_M))
        print("The time complexity of the preprocessing phase is T1: 2^{}".format(max_T1))
        print("The time complexity of the processing phase is T2: 2^{} ".format(max_T2))
        print("The time complexity is T=T1+T2: 2^{},".format(mmax_T))
        print("data complexity: 2^{}, memory complexity: 2^{}".format(max_N2, max_Memory))
        print("2^{}, 2^{}\n".format(math.log(max_B * (2 ** max_B) + 2 ** max_M, 2), math.log((2 ** max_B) * (2 + int(max_M)), 2)))

def main():

    pe = [-9]
    print("SNOW 2.0^oplus")
    FSR_A = 0
    tao(pe, FSR_A)

    pe = [-15.893]
    print("SNOW 3G^oplus")
    FSR_A = 0
    tao(pe, FSR_A)


    pe = [-37.964]
    print("SNOW 5G^oplus")
    FSR_A = 0
    tao(pe, FSR_A)


if __name__  == '__main__':
    main()
